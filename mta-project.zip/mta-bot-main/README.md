# Install Module 
`npm install`
`npm install gamedig`


# Setup Your Bot
`edit config.json`
`edit mta.js`

# Done !
![image](https://cdn.discordapp.com/attachments/910587827832623117/913717300161548318/unknown.png)
