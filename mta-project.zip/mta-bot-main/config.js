module.exports = {
  "token": "",
  "geliştiriciler": ["783759162374619168"], 
  "prefix": "!"
};